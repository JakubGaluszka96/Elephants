import Elephants


def test_set1():
    input="/testdata/slo1.in"
    output="/testdata/slo1.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set1"


def test_set2():
    input="/testdata/slo2.in"
    output="/testdata/slo2.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set2"


def test_set3():
    input="/testdata/slo3.in"
    output="/testdata/slo3.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set3"


def test_set4():
    input="/testdata/slo4.in"
    output="/testdata/slo4.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set4"


def test_set5():
    input="/testdata/slo5.in"
    output="/testdata/slo5.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set5"


def test_set6():
    input="/testdata/slo6.in"
    output="/testdata/slo6.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set6"


def test_set7():
    input="/testdata/slo7.in"
    output="/testdata/slo7.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set7"


def test_set8a():
    input="/testdata/slo8a.in"
    output="/testdata/slo8a.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set8a"


def test_set8b():
    input="/testdata/slo8b.in"
    output="/testdata/slo8b.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set8b"

def test_set9a():
    input="/testdata/slo9a.in"
    output="/testdata/slo9a.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set9a"


def test_set9b():
    input="/testdata/slo9b.in"
    output="/testdata/slo9b.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set9b"


def test_set10a():
    input="/testdata/slo10a.in"
    output="/testdata/slo10a.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set10a"


def test_set10b():
    input="/testdata/slo10b.in"
    output="/testdata/slo10b.out"
    result=Elephants.get_result(input)
    output_data=int(Elephants.read_file(output))
    assert result==output_data, "Incorretc result for set10b"



